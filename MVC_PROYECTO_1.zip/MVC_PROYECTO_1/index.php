<?php
require_once(__DIR__ . "/controller/videojuegoController.php");
header("Location: /MVC_PROYECTO_1/view/username/login.php");
exit();
?>