<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="videojuego.css">
    <link rel="stylesheet" href="tabla.css">
    
  </head>
  <body>
    <div class="menu container">
        <a href="#" class="logo">LOGO</a>
        <input type="checkbox" id="menu" />
        <label for="menu">
        <img src="images/images/menu.png" class="menu-icono" alt="menu">
        </label>
            <nav class="navbar">
                <ul>
                    <!--<li><a href="../username/index.php">Cerrar Sesion</a>-->
                    <?php
                      echo '<h3><a href="logout.php">Logout</h3></div>';
                    ?>
                    <!--</li>-->
                </ul>
            </nav>
    </div>
    

    


<div class="">
