<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="videojuego.css?v=1">
    
  </head>
  <body>
    <div class="menu container">
        <a href="#" class="logo">LOGO</a>
        <input type="checkbox" id="menu" />
        <label for="menu">
        <img src="images/images/menu.png" class="menu-icono" alt="menu">
        </label>
            <nav class="navbar">
                <ul>
                    <li><a href="../username/index.php">Inicio</a></li>
                    <li><a href="../username/login.php">Iniciar Sesion</a></li>
                </ul>
            </nav>
    </div>


<div class="">
