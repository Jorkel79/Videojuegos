
<footer class="footer container">
        <div>
            <a href="#" class="logo">LOGO</a>
        </div>
        <div class="link">
            <ul>
                <li><a href="">Inicio</a></li>
                <li><a href="">Iniciar Sesion</a></li>
            </ul>
        </div>
    </footer>