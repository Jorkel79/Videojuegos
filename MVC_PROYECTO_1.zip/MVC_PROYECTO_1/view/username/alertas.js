// alertas.js
function mostrarAlertaIntentosFallidos(mensaje) {
    alert(mensaje);
    window.location.href = 'login.php'; // Redirige al usuario al inicio de sesión después de mostrar la alerta
}
